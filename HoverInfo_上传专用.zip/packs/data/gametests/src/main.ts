/**
 *
 * @author
 * r4isen1920
 * https://mcpedl.com/user/r4isen1920
 *
 * @license
 * MIT License
 *
 */

import "./waila/utils/Logger";
import "./waila/utils/String";
import "./waila/utils/Version";
import "./waila/core/Settings";
import "./waila/core/Waila";

import { init } from "@bedrock-oss/stylish";
init();
